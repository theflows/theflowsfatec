#include <iostream>
#include "fila_ligada.h"
#include "pilhaligada.h"
#include <cstdlib>
#include <ctime>

using namespace std;

int main()
{
    Pilha<int> p;
    Fila<int> f;
    int opc;
    int x;
    cout << "Pilha e Fila" << endl;
    do{
        cout<<"1-carregar a fila"<<endl;
        cout<<"2-Transferir todos os elementos da Fila para uma Pilha"<<endl;
        cout<<"3-Transferir todos os elementos da pilha para a fila"<<endl;
        cout<<"4-Transferir todos os elementos da Fila para uma Pilha(crescente ou decrescente)"<<endl;
        cout<<"5-Exibir a Pilha"<<endl;
        cout<<"6-Exibir a Fila";
        cout<<"selecione: ";
        cin>>opc;
    switch(opc){
    case 1:
        for (int i=0;i<=19;i++){
        x=rand()%9;
        f.AdicionaFim(x);}
        break;
    case 2:
        Node<int> *aux = f.inicio;
                while (aux!=NULL){
                    cout<< aux->info<<" ";
                    aux= aux->prox;
                }
                cout<<endl;
        break;
    case 3:
        break;
    case 4:
        break;
    case 5:
        break;
    case 6:
        break;

    }
    }while(opc!=9);
    return 0;
}
